﻿CKEDITOR.plugins.setLang('youtube', 'en',
{
  youtube :
  {
    title : "Embed Youtube Video",
    button : "Add Youtube Video",
    pasteMsg : "Please copy and paste the id the Youtube video, which can be found in the URL of the video, EX. http://http://www.youtube.com/watch?v=<strong>Hs0QPBUjXv4</strong>"
  }
});
